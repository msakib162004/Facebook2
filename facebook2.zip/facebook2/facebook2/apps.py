from django.apps import AppConfig

class FBConfig(AppConfig):
	name='facebook2'